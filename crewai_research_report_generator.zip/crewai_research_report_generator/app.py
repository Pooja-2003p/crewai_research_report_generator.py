import streamlit as st
from dotenv import load_dotenv
from database import init_db, save_report, list_reports, get_report, search_memory
from report_export import to_pdf
from crew_service import run_research_crew

load_dotenv()
init_db()

st.set_page_config(page_title="CrewAI Research Studio", page_icon="🔎", layout="wide")
st.title("🔎 CrewAI Research & Report Generator")
st.caption("A multi-agent research assistant powered by CrewAI and the OpenAI API.")

with st.sidebar:
    st.header("Project features")
    st.markdown("- Research, analysis, and writing agents\n- SQLite report history\n- Persistent topic memory\n- Markdown and PDF downloads\n- Automated tests")
    st.info("OpenAI API usage may incur charges. Keep your API key private.")

topic = st.text_input("Research topic", placeholder="e.g., How AI is changing healthcare")
audience = st.selectbox("Report audience", ["General audience", "College assignment", "Business professionals", "Technical readers"])
depth = st.select_slider("Report depth", options=["Brief", "Standard", "Detailed"], value="Standard")
include_limitations = st.checkbox("Include limitations and open questions", value=True)

if topic.strip():
    with st.expander("Relevant past research"):
        memories = search_memory(topic.strip(), limit=5)
        if memories:
            for item in memories:
                st.markdown(f"**{item['topic']}** — {item['created_at']}")
                st.caption(item["summary"][:500])
        else:
            st.write("No matching saved research yet.")

if st.button("Generate report", type="primary", disabled=not bool(topic.strip())):
    try:
        with st.spinner("The agents are researching and writing. This can take a few minutes..."):
            report = run_research_crew(
                topic=topic.strip(),
                audience=audience,
                depth=depth,
                include_limitations=include_limitations,
            )
            report_id = save_report(
                topic=topic.strip(),
                audience=audience,
                depth=depth,
                content=report,
            )
        st.session_state["latest_report"] = report
        st.session_state["latest_report_id"] = report_id
        st.success(f"Report generated and saved. Report ID: {report_id}")
    except Exception as exc:
        st.error("The report could not be generated.")
        st.exception(exc)

report = st.session_state.get("latest_report")
if report:
    st.subheader("Generated report")
    st.markdown(report)
    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "Download Markdown",
            data=report,
            file_name="research_report.md",
            mime="text/markdown",
        )
    with col2:
        try:
            pdf_bytes = to_pdf(report, topic=topic or "Research Report")
            st.download_button(
                "Download PDF",
                data=pdf_bytes,
                file_name="research_report.pdf",
                mime="application/pdf",
            )
        except Exception as exc:
            st.warning(f"PDF export is unavailable: {exc}")

st.divider()
st.subheader("Saved report history")
history = list_reports(limit=20)
if not history:
    st.write("No reports saved yet.")
else:
    for item in history:
        with st.expander(f"#{item['id']} · {item['topic']} · {item['created_at']}"):
            st.caption(f"Audience: {item['audience']} | Depth: {item['depth']}")
            st.markdown(item["content"])
            st.download_button(
                "Download this report as Markdown",
                data=item["content"],
                file_name=f"report_{item['id']}.md",
                mime="text/markdown",
                key=f"download_{item['id']}",
            )
