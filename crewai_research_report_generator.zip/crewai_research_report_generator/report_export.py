from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.enums import TA_LEFT
from xml.sax.saxutils import escape
import re


def to_pdf(markdown_text: str, topic: str = "Research Report") -> bytes:
    """A lightweight Markdown-to-PDF exporter for headings and paragraphs."""
    output = BytesIO()
    doc = SimpleDocTemplate(
        output, pagesize=A4,
        rightMargin=0.7 * inch, leftMargin=0.7 * inch,
        topMargin=0.7 * inch, bottomMargin=0.7 * inch,
        title=topic,
    )
    styles = getSampleStyleSheet()
    story = []
    for raw in markdown_text.splitlines():
        line = raw.strip()
        if not line:
            story.append(Spacer(1, 6))
            continue
        if line.startswith("# "):
            style = styles["Title"]
            line = line[2:]
        elif line.startswith("## "):
            style = styles["Heading1"]
            line = line[3:]
        elif line.startswith("### "):
            style = styles["Heading2"]
            line = line[4:]
        else:
            style = styles["BodyText"]
            if line.startswith(("- ", "* ")):
                line = "• " + line[2:]
            line = re.sub(r"\*\*(.*?)\*\*", r"\1", line)
            line = re.sub(r"\*(.*?)\*", r"\1", line)
            line = re.sub(r"`(.*?)`", r"\1", line)
        story.append(Paragraph(escape(line), style))
    doc.build(story)
    return output.getvalue()
