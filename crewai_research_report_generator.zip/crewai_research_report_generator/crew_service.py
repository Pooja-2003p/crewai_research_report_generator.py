import os
from crewai import Agent, Crew, Process, Task, LLM
from search_tool import WebSearchTool
from database import search_memory, save_memory

DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "openai/gpt-4o-mini")


def _make_llm():
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is missing. Add your OpenAI API key to the .env file."
        )
    return LLM(model=DEFAULT_MODEL, temperature=0.2)


def run_research_crew(topic: str, audience: str = "General audience",
                      depth: str = "Standard", include_limitations: bool = True) -> str:
    """Run a three-agent research workflow and return a Markdown report."""
    topic = topic.strip()
    if not topic:
        raise ValueError("Research topic cannot be empty.")

    llm = _make_llm()
    prior = search_memory(topic, limit=3)
    memory_context = "\n".join(
        f"- Previous topic: {x['topic']}\n  Summary: {x['summary']}"
        for x in prior
    ) or "No relevant prior research found in the local research memory."

    search_tool = WebSearchTool()
    researcher = Agent(
        role="Research Analyst",
        goal="Gather useful, relevant, verifiable information and clearly identify sources.",
        backstory=(
            "You are a careful research analyst. You distinguish evidence from assumptions, "
            "prefer trustworthy sources, and never invent citations or URLs."
        ),
        tools=[search_tool],
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )
    analyst = Agent(
        role="Evidence Analyst",
        goal="Synthesize research into accurate findings, comparisons, and practical insights.",
        backstory=(
            "You critically evaluate claims, note conflicting evidence, and avoid unsupported conclusions."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )
    writer = Agent(
        role="Report Writer",
        goal="Create a clear, structured report for the specified audience.",
        backstory=(
            "You write professional reports with headings, a concise summary, evidence-based findings, "
            "limitations, and a references section."
        ),
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )

    research_task = Task(
        description=(
            "Research this topic: {topic}\n"
            "Use the web search tool multiple times with focused queries. Prefer official, academic, "
            "or reputable sources. Return key facts, dates where relevant, source titles, and exact URLs. "
            "Do not make up sources. Mention where evidence is uncertain.\n"
            f"Audience: {audience}. Desired depth: {depth}.\n"
            f"Relevant context from earlier saved research (verify before reusing):\n{memory_context}"
        ),
        expected_output="Research notes with evidence, source titles and URLs, and uncertainty notes.",
        agent=researcher,
    )
    analysis_task = Task(
        description=(
            "Analyze the research notes. Group findings by theme, explain implications for the audience, "
            "identify disagreements and gaps, and separate sourced facts from interpretation. "
            "Do not add unsupported facts."
        ),
        expected_output="A structured synthesis with major findings, implications, and caveats.",
        agent=analyst,
        context=[research_task],
    )
    limitations_instruction = (
        "Include a section titled 'Limitations and Open Questions'."
        if include_limitations else
        "Include a brief caveats paragraph where appropriate."
    )
    writing_task = Task(
        description=(
            "Write the final report on: {topic}\n"
            f"Audience: {audience}. Depth: {depth}.\n"
            "Use Markdown with a title, date-independent executive summary, introduction, thematic findings, "
            "practical implications or recommendations, and a references list containing only URLs present "
            "in the research notes. Clearly label uncertainty. "
            f"{limitations_instruction}\n"
            "Do not claim you verified a source unless it appears in the supplied research."
        ),
        expected_output="A polished, standalone Markdown report with references.",
        agent=writer,
        context=[research_task, analysis_task],
    )
    crew = Crew(
        agents=[researcher, analyst, writer],
        tasks=[research_task, analysis_task, writing_task],
        process=Process.sequential,
        verbose=True,
        memory=True,
    )
    result = crew.kickoff(inputs={"topic": topic})
    report = str(result)
    save_memory(topic=topic, summary=report[:1800])
    return report
