import database


def test_save_and_get_report(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "test.db")
    database.init_db()
    report_id = database.save_report("AI in education", "College assignment", "Standard", "# Report")
    result = database.get_report(report_id)
    assert result is not None
    assert result["topic"] == "AI in education"
    assert result["content"] == "# Report"


def test_memory_search(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "test.db")
    database.init_db()
    database.save_memory("Climate change", "Renewable energy and emissions")
    results = database.search_memory("Climate")
    assert len(results) == 1
    assert results[0]["topic"] == "Climate change"


def test_empty_memory_query(tmp_path, monkeypatch):
    monkeypatch.setattr(database, "DB_PATH", tmp_path / "test.db")
    database.init_db()
    assert database.search_memory("   ") == []
