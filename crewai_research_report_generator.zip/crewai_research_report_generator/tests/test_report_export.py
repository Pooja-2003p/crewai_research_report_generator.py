from report_export import to_pdf


def test_pdf_export_returns_pdf_bytes():
    data = to_pdf("# Example Report\n\n## Findings\nSome findings.", topic="Example")
    assert data.startswith(b"%PDF")
