import os
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(os.getenv("DATABASE_PATH", "data/research.db"))


def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL,
                audience TEXT NOT NULL,
                depth TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                topic TEXT NOT NULL,
                summary TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def save_report(topic: str, audience: str, depth: str, content: str) -> int:
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO reports(topic, audience, depth, content, created_at) VALUES (?, ?, ?, ?, ?)",
            (topic, audience, depth, content, _now()),
        )
        return int(cursor.lastrowid)


def list_reports(limit: int = 20):
    limit = max(1, min(int(limit), 100))
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, topic, audience, depth, created_at, content FROM reports ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def get_report(report_id: int):
    with _connect() as conn:
        row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    return dict(row) if row else None


def save_memory(topic: str, summary: str):
    with _connect() as conn:
        conn.execute(
            "INSERT INTO memories(topic, summary, created_at) VALUES (?, ?, ?)",
            (topic, summary, _now()),
        )


def search_memory(query: str, limit: int = 5):
    """Simple persistent keyword memory. This is not semantic/vector search."""
    query = query.strip()
    limit = max(1, min(int(limit), 50))
    if not query:
        return []
    pattern = f"%{query}%"
    with _connect() as conn:
        rows = conn.execute(
            """SELECT topic, summary, created_at FROM memories
               WHERE topic LIKE ? OR summary LIKE ?
               ORDER BY id DESC LIMIT ?""",
            (pattern, pattern, limit),
        ).fetchall()
    return [dict(row) for row in rows]
