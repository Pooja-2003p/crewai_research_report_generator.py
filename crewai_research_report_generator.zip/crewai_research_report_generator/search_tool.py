from typing import Type
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
from ddgs import DDGS


class SearchInput(BaseModel):
    query: str = Field(..., description="A concise web search query.")


class WebSearchTool(BaseTool):
    name: str = "Web Search"
    description: str = (
        "Search the public web for relevant pages. Input a concise query. "
        "Returns result titles, snippets, and URLs. Search results should be verified."
    )
    args_schema: Type[BaseModel] = SearchInput

    def _run(self, query: str) -> str:
        if not query.strip():
            return "Search query was empty."
        try:
            results = DDGS().text(query, max_results=6)
            rows = []
            for result in results or []:
                rows.append(
                    f"Title: {result.get('title', 'Untitled')}\n"
                    f"Snippet: {result.get('body', '')}\n"
                    f"URL: {result.get('href', '')}"
                )
            return "\n\n".join(rows) if rows else "No results found. Try a more specific query."
        except Exception as exc:
            return f"Search failed: {type(exc).__name__}: {exc}. Try a different query later."
