# CrewAI Research & Report Generator

A multi-agent research app built with CrewAI, OpenAI, Streamlit, SQLite, DuckDuckGo search, and ReportLab.

## Features
- Research, analysis, and report-writing agents
- Public web search tool
- SQLite report history
- Persistent keyword-based research memory
- CrewAI native memory enabled for agent collaboration
- Markdown and PDF downloads
- Pytest tests
- Docker packaging

## Requirements
- Python 3.10–3.13 recommended for current CrewAI compatibility
- OpenAI API key with API access/billing configured
- Internet access for model calls and web search

## Local setup (Windows PowerShell)
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set `OPENAI_API_KEY` to your own key. Never commit `.env` or share your key.

Run:
```powershell
streamlit run app.py
```
Open the local URL printed in the terminal, usually http://localhost:8501.

## Run tests
```powershell
pytest -q
```
Tests use a temporary SQLite database and do not call OpenAI.

## Docker
```bash
docker compose up --build
```
Then open http://localhost:8501. The `data` folder is mounted so the SQLite database survives container restarts.

## Deployment
Deploy to a Python-capable host such as a container service. Set `OPENAI_API_KEY` and `DATABASE_PATH` as environment variables/secrets. For Streamlit Community Cloud, add the key under app secrets and adjust configuration to read `st.secrets` if environment variables are not injected by the host. SQLite is suitable for a small demo; use managed PostgreSQL and durable storage for multi-user production use.

## Important notes
- Model and search usage may incur costs or be subject to provider rate limits.
- Search snippets are not guaranteed to be correct. Check source links before relying on important claims.
- The included keyword memory is a simple local retrieval feature, not semantic/vector search.
- Do not expose the app publicly without authentication, rate limiting, and abuse protections.
- CrewAI native memory behavior can vary by installed version; test it in your environment and pin versions after confirming a working setup.
